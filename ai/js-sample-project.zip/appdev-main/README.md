# WHSPR

A full-stack web application that provides speech-to-text transcription, text summarization, and translation services. Built with React frontend and Flask backend.

## System Architecture

The system consists of two main components:
- Frontend: React-based web application
- Backend: Flask-based REST API

## Features

### Core Features
- Speech-to-Text Transcription using IBM Watson
- Text Summarization using OpenAI API
- Text Translation using OpenAI API
- User Authentication and Authorization
- Secure Session Management

### Frontend Features
- Modern, responsive user interface
- Real-time audio recording and processing
- Interactive text editing and management
- User profile management
- Secure authentication flow

### Backend Features
- RESTful API endpoints
- Secure user authentication
- File upload and processing
- Integration with AI services
- CORS support for frontend communication

## Tech Stack

### Frontend
- React 18
- React Router v6
- Modern JavaScript (ES6+)
- CSS3 for styling

### Backend
- Python 3.x
- Flask
- SQLAlchemy
- IBM Watson Speech-to-Text
- OpenAI API
- SendGrid for email services

## Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0
- Python 3.x
- pip

## Installation

### Frontend Setup
1. Navigate to the project root directory
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm start
   ```
   The frontend will be available at `http://localhost:3000`

### Backend Setup
1. Navigate to the `app` directory
2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Set up environment variables (see Environment Variables section)
5. Initialize the database:
   ```bash
   flask db init
   flask db migrate
   flask db upgrade
   ```
6. Start the backend server:
   ```bash
   python app/main.py
   ```
   The backend will be available at `http://localhost:5000`

## Environment Variables

Create a `.env` file in the `app` directory with the following variables:

```env
SECRET_KEY=your_secret_key
MAIL_PASSWORD=your_sendgrid_api_key
MAIL_DEFAULT_SENDER=your_verified_sender_email
SPEECH_TO_TEXT_APIKEY=your_ibm_watson_api_key
SPEECH_TO_TEXT_URL=your_ibm_watson_url
OPENAI_API_KEY=your_openai_api_key
```

## API Documentation

### Authentication Endpoints

#### Sign Up
- **POST** `/api/sign-up`
- Creates a new user account

#### Login
- **POST** `/api/login`
- Authenticates user and creates session

#### Logout
- **POST** `/api/logout`
- Ends user session

#### Password Reset
- **POST** `/api/reset_password`
- Initiates password reset process
- **POST** `/api/reset_password/<token>`
- Completes password reset

### Feature Endpoints

#### Transcribe Audio
- **POST** `/api/transcribe`
- Converts audio to text

#### Summarize Text
- **POST** `/api/summarize`
- Generates text summary using OpenAI API

#### Translate Text
- **POST** `/api/translate`
- Translates text to target language using OpenAI API

## Development

### Frontend Development
- Uses Create React App for development
- Supports hot reloading
- Includes testing setup with Jest

### Backend Development
- Flask development server with debug mode
- SQLAlchemy for database operations
- Flask-Migrate for database migrations

## Deployment

### Frontend Deployment
- Build the production version:
  ```bash
  npm run build
  ```
- Deploy the `build` directory to your hosting service

### Backend Deployment
- Configure production environment variables
- Use a production-grade WSGI server (e.g., Gunicorn)
- Set up a production database

## Security

- Password hashing using Werkzeug
- Session-based authentication
- CORS protection
- Secure password reset tokens
- Environment variable configuration
- HTTPS enforcement in production

## Error Handling

The system implements comprehensive error handling:
- Frontend: User-friendly error messages
- Backend: Standardized error responses with appropriate HTTP status codes
- Logging for debugging and monitoring

## License

This project is licensed under the MIT License - see the LICENSE file for details.

