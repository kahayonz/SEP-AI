import requests
import json
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from flask_cors import cross_origin
import os
from dotenv import load_dotenv

BASEDIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASEDIR, 'ibm-credentials.env'))
STT_APIKEY = os.getenv('SPEECH_TO_TEXT_APIKEY')
STT_APIURL = os.getenv('SPEECH_TO_TEXT_URL')
AI_API_KEY = os.getenv('AI_API_KEY')

# Supported audio formats and their MIME types
SUPPORTED_AUDIO_FORMATS = {
    'wav': 'audio/wav',
    'mp3': 'audio/mp3',
    'ogg': 'audio/ogg',
    'flac': 'audio/flac',
    'webm': 'audio/webm'
}

views = Blueprint('views', __name__)

@views.route('/user', methods=['GET'])
@login_required
def get_user():
    return jsonify({
        'id': current_user.id,
        'email': current_user.email,
        'first_name': current_user.firstName
    })

@views.route("/transcribe", methods=["POST"])
@cross_origin()
def transcribe():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    audio_file = request.files["file"]
    
    # Get file extension and validate format
    file_extension = audio_file.filename.rsplit('.', 1)[1].lower() if '.' in audio_file.filename else ''
    if file_extension not in SUPPORTED_AUDIO_FORMATS:
        return jsonify({
            "error": "Unsupported audio format",
            "supported_formats": list(SUPPORTED_AUDIO_FORMATS.keys())
        }), 400

    temp_path = f"uploaded_audio.{file_extension}"
    audio_file.save(temp_path)

    auth = ("apikey", STT_APIKEY)
    headers = {"Content-Type": SUPPORTED_AUDIO_FORMATS[file_extension]}

    with open(temp_path, "rb") as f:
        response = requests.post(
            STT_APIURL + "/v1/recognize",
            headers=headers,
            auth=auth,
            data=f
        )

    os.remove(temp_path)

    if response.status_code != 200:
        print(response.text)
        return jsonify({"error": "Failed to process audio", "details": response.text}), response.status_code
    
    transcription_text = response.json()['results'][0]['alternatives'][0]['transcript']
    return jsonify({'text': transcription_text}), 200

@views.route("/summarize", methods=["POST"])
@cross_origin()
def summarize():
    content = request.get_json()['content']
    content = "Summarize the following without reasoning:\n" + content
    response = requests.post(
        url="https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {AI_API_KEY}",
            "Content-Type": "application/json",
        },
        data=json.dumps({
            "model": "openai/gpt-4.1-nano",
            "messages": [
            {
                "role": "user",
                "content": content
            }
            ],
        })
    )

    if response.status_code != 200:
        return jsonify({"error": "Failed to process audio", "details": response.text}), response.status_code
    
    summary = response.json()["choices"][0]["message"]["content"]
    return jsonify({'summary': summary}), 200

@views.route("/translate", methods=["POST"])
@cross_origin()
def translate():
    content = request.get_json()['content']
    language = request.get_json()['language']
    content = f"Translate the following text into {language} language. Omit the reasoning:\n" + content
    response = requests.post(
        url="https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {AI_API_KEY}",
            "Content-Type": "application/json",
        },
        data=json.dumps({
            "model": "openai/gpt-4.1-nano",
            "messages": [
            {
                "role": "user",
                "content": content
            }
            ],
        })
    )

    if response.status_code != 200:
        return jsonify({"error": "Failed to process audio", "details": response.text}), response.status_code
    
    translation = response.json()["choices"][0]["message"]["content"]
    return jsonify({'translation': translation}), 200