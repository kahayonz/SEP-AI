from flask import Blueprint, request, jsonify, current_app, session, render_template
from .models import User
from werkzeug.security import generate_password_hash, check_password_hash
from . import mail, s
from flask_mail import Message
from flask_login import login_user, login_required, logout_user, current_user
from flask_cors import cross_origin
import jwt
from datetime import datetime, timedelta

auth = Blueprint('auth', __name__)

@auth.route('/reset_password', methods=['POST'])
@cross_origin()
def reset_request():
    email = request.json.get('email')
    user = User.get_by_email(email)
    if user:
        token = s.dumps(email, salt='password-reset')
        reset_link = f"{request.host_url}api/reset_password/{token}"
        msg = Message(
            'Password Reset Request',
            sender=current_app.config['MAIL_DEFAULT_SENDER'],
            recipients=[email]
        )
        msg.body = f'Click the link to reset your password: {reset_link}'
        mail.send(msg)
        print(reset_link)
        return jsonify({'message': 'Check your email for a password reset link.'}), 200
    else:
        return jsonify({'error': 'Email not found.'}), 404

@auth.route('/reset_password/<token>', methods=['POST'])
@cross_origin()
def reset_password(token):
    try:
        email = s.loads(token, salt='password-reset', max_age=3600)
        user = User.get_by_email(email)

        if not user:
            return jsonify({'error': 'Invalid or expired token'}), 400

        new_password = request.json.get('password')
        user.set_password(new_password)
        # Update password in Supabase
        from . import supabase
        supabase.table('users').update({'password_hash': user.password_hash}).eq('id', user.id).execute()
        
        return jsonify({'message': 'Your password has been updated! You can log in now.'}), 200
    except:
        return jsonify({'error': 'Invalid or expired token'}), 400

@auth.route('/reset_password/<token>', methods=['GET'])
@cross_origin()
def reset_password_page(token):
    try:
        # Verify the token is valid
        email = s.loads(token, salt='password-reset', max_age=3600)
        return render_template('reset_password.html')
    except:
        return render_template('reset_password.html', error='Invalid or expired token')

@auth.route('/login', methods=['POST'])
@cross_origin()
def login():
    email = request.json.get('email')
    password = request.json.get('password')
    
    user = User.get_by_email(email)
    if not user:
        return jsonify({'error': 'Email not found. Please register first.'}), 404

    if not user.password_hash:
        return jsonify({'error': 'Password not set for this account. Try resetting it.'}), 400

    if check_password_hash(user.password_hash, password):
        session['user_id'] = user.id
        login_user(user, remember=True)
        
        # Create JWT token
        token = jwt.encode({
            'user_id': user.id,
            'email': user.email,
            'exp': datetime.utcnow() + timedelta(days=1)  # Token expires in 1 day
        }, current_app.config['SECRET_KEY'], algorithm='HS256')
        
        # Convert bytes to string if needed (PyJWT >= 2.0.0 returns bytes)
        if isinstance(token, bytes):
            token = token.decode('utf-8')
        
        return jsonify({
            'message': 'Login successful!',
            'token': token,
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.firstName
            }
        }), 200
    else:
        return jsonify({'error': 'Invalid email or password.'}), 401

@auth.route('/logout', methods=['POST'])
@cross_origin()
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'You have been logged out.'}), 200

@auth.route('/sign-up', methods=['POST'])
@cross_origin()
def sign_up():
    email = request.json.get('email')
    firstName = request.json.get('firstName')
    password1 = request.json.get('password1')
    password2 = request.json.get('password2')

    user = User.get_by_email(email)
    if user:
        return jsonify({'error': 'Email already exists.'}), 400
    elif len(email) < 4:
        return jsonify({'error': 'Email must be greater than 3 characters.'}), 400
    elif len(firstName) < 2:
        return jsonify({'error': 'First name must be greater than 1 character.'}), 400
    elif password1 != password2:
        return jsonify({'error': "Passwords don't match."}), 400
    elif len(password1) < 7:
        return jsonify({'error': 'Password must be at least 7 characters.'}), 400
    else:
        new_user = User.create(email=email, firstName=firstName, password=password1)
        if new_user:
            login_user(new_user, remember=True)
            return jsonify({
                'message': 'Account created!',
                'user': {
                    'id': new_user.id,
                    'email': new_user.email,
                    'first_name': new_user.firstName
                }
            }), 201
        return jsonify({'error': 'Failed to create account.'}), 500
