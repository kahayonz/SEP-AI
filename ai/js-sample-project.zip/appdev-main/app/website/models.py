from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from . import supabase

class User(UserMixin):
    def __init__(self, id, email, firstName, password_hash=None):
        self.id = id
        self.email = email
        self.firstName = firstName
        self.password_hash = password_hash

    def set_password(self, password):
        """Hashes the password before storing it."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Checks the password against the stored hash."""
        return check_password_hash(self.password_hash, password)

    @staticmethod
    def get_by_email(email):
        """Get user by email from Supabase."""
        response = supabase.table('users').select('*').eq('email', email).execute()
        if response.data:
            user_data = response.data[0]
            return User(
                id=user_data['id'],
                email=user_data['email'],
                firstName=user_data['firstName'],
                password_hash=user_data['password_hash']
            )
        return None

    @staticmethod
    def create(email, firstName, password):
        """Create a new user in Supabase."""
        password_hash = generate_password_hash(password)
        response = supabase.table('users').insert({
            'email': email,
            'firstName': firstName,
            'password_hash': password_hash
        }).execute()
        
        if response.data:
            user_data = response.data[0]
            return User(
                id=user_data['id'],
                email=user_data['email'],
                firstName=user_data['firstName'],
                password_hash=user_data['password_hash']
            )
        return None