# Backend

A Flask-based backend API that provides speech-to-text transcription, text summarization, and translation services with user authentication.

## Features

- User Authentication (Sign up, Login, Logout, Password Reset)
- Speech-to-Text Transcription using IBM Watson
- Text Summarization using OpenAI API
- Text Translation using OpenAI API
- Secure Session Management
- CORS Support for React Frontend

## API Endpoints

### Authentication

#### Sign Up
- **POST** `/api/sign-up`
- **Request Body:**
  ```json
  {
    "email": "user@example.com",
    "firstName": "John",
    "password1": "password123",
    "password2": "password123"
  }
  ```
- **Response:**
  ```json
  {
    "message": "Account created!",
    "user": {
      "id": 1,
      "email": "user@example.com",
      "first_name": "John"
    }
  }
  ```

#### Login
- **POST** `/api/login`
- **Request Body:**
  ```json
  {
    "email": "user@example.com",
    "password": "password123"
  }
  ```
- **Response:**
  ```json
  {
    "message": "Login successful!",
    "user": {
      "id": 1,
      "email": "user@example.com",
      "first_name": "John"
    }
  }
  ```

#### Logout
- **POST** `/api/logout`
- **Response:**
  ```json
  {
    "message": "You have been logged out."
  }
  ```

#### Password Reset Request
- **POST** `/api/reset_password`
- **Request Body:**
  ```json
  {
    "email": "user@example.com"
  }
  ```
- **Response:**
  ```json
  {
    "message": "Check your email for a password reset link."
  }
  ```

#### Password Reset with Token
- **POST** `/api/reset_password/<token>`
- **Request Body:**
  ```json
  {
    "password": "newpassword123"
  }
  ```
- **Response:**
  ```json
  {
    "message": "Your password has been updated! You can log in now."
  }
  ```

### Features

#### Transcribe Audio
- **POST** `/api/transcribe`
- **Request:** Form data with audio file
- **Response:**
  ```json
  {
    "text": "Transcribed text from audio"
  }
  ```

#### Summarize Text
- **POST** `/api/summarize`
- **Request Body:**
  ```json
  {
    "content": "Text to be summarized"
  }
  ```
- **Response:**
  ```json
  {
    "summary": "Summarized text using OpenAI API"
  }
  ```

#### Translate Text
- **POST** `/api/translate`
- **Request Body:**
  ```json
  {
    "content": "Text to translate",
    "language": "target language"
  }
  ```
- **Response:**
  ```json
  {
    "translation": "Translated text using OpenAI API"
  }
  ```

## Environment Variables

Create a `.env` file with the following variables:

```env
SECRET_KEY=your_secret_key
MAIL_PASSWORD=your_sendgrid_api_key
MAIL_DEFAULT_SENDER=your_verified_sender_email
SPEECH_TO_TEXT_APIKEY=your_ibm_watson_api_key
SPEECH_TO_TEXT_URL=your_ibm_watson_url
OPENAI_API_KEY=your_openai_api_key
```

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Initialize the database:
   ```bash
   flask db init
   flask db migrate
   flask db upgrade
   ```

3. Run the application:
   ```bash
   python app/main.py
   ```
