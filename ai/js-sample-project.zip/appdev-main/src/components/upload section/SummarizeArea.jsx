import React, { useState, useEffect, useRef } from "react";
import "../../stylesheets/summarize.css";

function SummarizeArea() {
  const [inputText, setInputText] = useState("");
  const [outputText, setOutputText] = useState("");
  const textFieldRef = useRef(null);

  // Load saved text from localStorage when the component mounts
  useEffect(() => {
    const savedText = localStorage.getItem("savedText");
    if (savedText) {
      setInputText(savedText);
    }
  }, []);

  const handleSummarize = async () => {
    const API_BASE_URL = 'https://appdev-z193.onrender.com/api';

    try {
      const response = await fetch(`${API_BASE_URL}/summarize`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: inputText,
        }),
      });
      const data = await response.json();
      setOutputText(data.summary);
    } catch (error) {
      console.error("Error summarizing:", error);
    }
  };

  // Save the input text to localStorage whenever it changes
  const handleTextChange = (e) => {
    setInputText(e.target.value);
    localStorage.setItem("savedText", e.target.value);
  };

  // Copy functionality
  const handleCopy = () => {
    const textField = document.querySelector(".output-text");
    textField.select();
    document.execCommand("copy");
};

  // Download functionality
  const handleDownload = () => {
    const textFieldContent = outputText;
    const converted = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head><meta charset='utf-8'></head>
        <body>${textFieldContent}</body>
      </html>`;
    const blob = new Blob(["\ufeff", converted], {
      type: "application/msword",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "transcription.doc";
    link.click();
  };
  

  return (
    <div className="summarize-container">
      <main>
        <div>
          <a className="btn summarize-choice-btn">Summarize</a>
          <a href="translate" className="btn translate-choice-btn">Translate</a>
        </div>
        <div className="upload-area">
          {/* Integrated Side-by-Side Text Areas */}
          <div className="text-container">
            <textarea
              className="text-field input-text"
              placeholder="Input text here..."
              value={inputText}
              onChange={handleTextChange}
            />
            <div className="separator"></div>
            <textarea
              className="text-field output-text"
              placeholder="Output text here..."
              disabled={!outputText}
              value={outputText}
              onChange={(e) => setOutputText(e.target.value)}
            />
          </div>
          {/* Existing Buttons */}
          <button onClick={handleSummarize} className="btn summarize-btn shared-hover-effect">
            Summarize
          </button>
          <a href="/" className="btn cancel-btn shared-hover-effect">
            Cancel
          </a>
          <button className="btn download-btn shared-hover-effect" onClick={handleDownload}>
            Download
          </button>
          <button className="btn copy-btn shared-hover-effect" onClick={handleCopy}>
            Copy
          </button>
        </div>
      </main>
      {/* Hidden File Input */}
      <input
        type="file"
        id="audio-upload"
        accept=".mp3, .wav, .m4a, .aac, .ogg, .flac"
        style={{ display: "none" }}
      />
    </div>
  );
}

export default SummarizeArea;
