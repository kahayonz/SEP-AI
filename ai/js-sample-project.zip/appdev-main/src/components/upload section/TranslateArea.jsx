import React, { useState, useEffect, useRef } from "react";
import "../../stylesheets/translate.css";

const primaryLanguages = [
  { label: "English", code: "English" },
  { label: "Filipino", code: "Filipino" },
  { label: "Chinese", code: "Chinese" },
  { label: "Japanese", code: "Japanese" },
  { label: "Korean", code: "Korean" }
];


function TranslateArea() {
  const [inputText, setInputText] = useState("");
  const [outputText, setOutputText] = useState("");
  const [selectedLang, setSelectedLang] = useState("en");
  const [showMore, setShowMore] = useState(false);
  const textFieldRef = useRef(null);

  // Load saved text from localStorage when the component mounts
  useEffect(() => {
    const savedText = localStorage.getItem("savedText");
    if (savedText) {
      setInputText(savedText);
    }
  }, []);

  const handleTranslate = async () => {
    const API_BASE_URL = 'https://appdev-z193.onrender.com/api';

    try {
      const response = await fetch(`${API_BASE_URL}/translate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: inputText, 
          language: selectedLang,
        }),
      });
      const data = await response.json();
      setOutputText(data.translation);
    } catch (error) {
      console.error("Error translating:", error);
    }
  };

  // Save the input text to localStorage whenever it changes
  const handleTextChange = (e) => {
    const updatedText = e.target.value;
    setInputText(updatedText);
    localStorage.setItem("savedText", updatedText);
  };

  // Copy functionality
  const handleCopy = () => {
    const textField = document.querySelector(".output-text");
    textField.select();
    document.execCommand("copy");
  };

  // Download functionality
  const handleDownload = () => {
    const textFieldContent = outputText;
    const converted = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head><meta charset='utf-8'></head>
        <body>${outputText}</body>
      </html>`;
    const blob = new Blob(["\ufeff", converted], {
      type: "application/msword",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "transcription.doc";
    link.click();
  };

  return (
    <div className="translate-container">
      <main>
        <div className="nav-buttons">
          <a href="summarize" className="btn summarize-choice-btn">
            Summarize
          </a>
          <a className="btn translate-choice-btn">Translate</a>
        </div>

        {/* Language Tabs (Now directly above the text container) */}
        <div className="language-tabs">
          {primaryLanguages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => setSelectedLang(lang.code)}
              className={`lang-tab-btn ${
                selectedLang === lang.code ? "active" : ""
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>

        <div className="upload-area">
          <div className="text-container">
            <textarea
              className="text-field input-text"
              placeholder="Input text here..."
              value={inputText}
              onChange={handleTextChange}
            />
            <div className="separator"></div>
            <textarea
              className="text-field output-text"
              placeholder="Output text here..."
              disabled={!outputText}
              value={outputText}
              onChange={(e) => setOutputText(e.target.value)}
            />
          </div>

          {/* Action Buttons */}
          <div className="button-group">
            <button
              className="btn copy-btn shared-hover-effect"
              onClick={handleCopy}
            >
              Copy
            </button>
            <button
              className="btn download-btn shared-hover-effect"
              onClick={handleDownload}
            >
              Download
            </button>
            <a href="/" className="btn cancel-btn shared-hover-effect">
              Cancel
            </a>
            <button
              onClick={handleTranslate}
              className="btn translate-btn shared-hover-effect"
            >
              Translate
            </button>
          </div>
        </div>
      </main>

      {/* Hidden File Input */}
      <input
        type="file"
        id="audio-upload"
        accept=".mp3, .wav, .m4a, .aac, .ogg, .flac"
        style={{ display: "none" }}
      />
    </div>
  );
}

export default TranslateArea;
