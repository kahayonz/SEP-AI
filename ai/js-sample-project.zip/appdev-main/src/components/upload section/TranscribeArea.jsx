import React, { useState, useEffect, useRef } from "react";
import "../../stylesheets/transcribed.css"; // Scoped styles

function TranscribeArea() {
  const [text, setText] = useState(""); 
  const textFieldRef = useRef(null); 

  // Load saved text from localStorage when the component mounts
  useEffect(() => {
    try {
      const savedText = localStorage.getItem("savedText"); 
      if (savedText) {
        setText(savedText); 
      }
    } catch (error) {
      console.error("Failed to load text from localStorage:", error);
    }
  }, []);

  // Save the text to localStorage whenever it changes
  const handleTextChange = (e) => {
    const updatedText = e.target.value;
    setText(updatedText); 
    try {
      localStorage.setItem("savedText", updatedText); 
    } catch (error) {
      console.error("Failed to save text to localStorage:", error);
    }
  };

  // Copy functionality
  const handleCopy = () => {
    try {
      const textField = textFieldRef.current;
      textField.select(); 
      document.execCommand("copy"); 
    } catch (error) {
      console.error("Failed to copy text:", error);
    }
  };

  // Download functionality
  const handleDownload = () => {
    try {
      const converted = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
          <head><meta charset='utf-8'></head>
          <body>${text}</body>
        </html>`;
      const blob = new Blob(["\ufeff", converted], {
        type: "application/msword",
      });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "transcription.doc";
      link.click();
    } catch (error) {
      console.error("Failed to download text:", error);
    }
  };

  return (
    <div className="transcribed-container">
      <main>
        <div>
          <div className="upload-area">
            <textarea
              ref={textFieldRef}
              className="text-field"
              placeholder="Your text content here..."
              value={text} 
              onChange={handleTextChange} 
            />
            <button
              className="btn download-btn shared-hover-effect"
              onClick={handleDownload}
            >
              Download
            </button>
            <button
              className="btn copy-btn shared-hover-effect"
              onClick={handleCopy}
            >
              Copy
            </button>
          </div>
          <div>
            <a
              href="summarize"
              className="btn summarize-or-translate-choice-btn"
            >
              Summarize or Translate
            </a>
          </div>
        </div>
      </main>
      <input
        type="file"
        id="audio-upload"
        accept=".mp3, .wav, .m4a, .aac, .ogg, .flac"
        style={{ display: "none" }}
      />
    </div>
  );
}

export default TranscribeArea;
