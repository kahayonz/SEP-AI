import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../stylesheets/global.css';
import '../stylesheets/logout.css';

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Clear the authentication token
    localStorage.removeItem('token');
    
    // Redirect to login page after a short delay
    const timer = setTimeout(() => {
      navigate('/login');
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="logout-container">
      <div className="logout-card">
        <div className="logout-spinner"></div>
        <h2>Logging Out</h2>
        <p>Thank you for using our service</p>
        <div className="logout-progress">
          <div className="progress-bar"></div>
        </div>
      </div>
    </div>
  );
};

export default Logout;
