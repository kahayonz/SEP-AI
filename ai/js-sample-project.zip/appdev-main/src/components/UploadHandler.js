export const handleFileClick = () => {
  const fileInput = document.getElementById("audio-upload");
  if (fileInput) {
    fileInput.click();
  } else {
    console.error("File input element not found.");
  }
};

export const handleFileChange = (event) => {
  const files = event.target.files;
  if (files.length > 0) {
    const selectedFile = files[0];
    const selectedFileName = selectedFile.name;

    // Save file name to localStorage
    localStorage.setItem("uploadedFileName", selectedFileName);

    // Show upload area 2
    document.querySelector(".upload-area").style.display = "none";
    document.querySelector(".upload-area2").style.display = "block";

    const uploadedFileElement = document.getElementById("uploadedFile");
    if (uploadedFileElement) {
      uploadedFileElement.textContent = `Uploaded file: ${selectedFileName}`;
    } else {
      console.error("Uploaded file element not found.");
    }
  } else {
    console.error("No file selected.");
  }
};

// export const handleUpload = async (event) => {
//   event.preventDefault();
//   const fileInput = document.getElementById("audio-upload");
//   const file = fileInput?.files[0];
//   if (!file) {
//     console.error("No file selected.");
//     return;
//   }

//   // Update UI
//   const uploadedFileElement = document.getElementById("uploadedFile");
//   const uploadBtn = document.querySelector(".upload-btn");
//   const cancelBtn = document.querySelector(".cancel-btn");

//   if (uploadedFileElement) {
//     uploadedFileElement.textContent = "Transcribing text...";
//   }
//   if (uploadBtn) uploadBtn.style.display = "none";
//   if (cancelBtn) cancelBtn.style.display = "none";

//   const API_BASE_URL = 'https://appdev-z193.onrender.com/api';
//   const formData = new FormData();
//   formData.append("file", file);

//   try {
//     const response = await fetch(`${API_BASE_URL}/transcribe`, {
//       method: "POST",
//       headers: {
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       },
//       body: formData,
//       credentials: 'include'
//     });

//     if (!response.ok) {
//       const errorData = await response.json();
//       throw new Error(errorData.error || 'Failed to transcribe audio');
//     }

//     const data = await response.json();
    
//     // Save transcribed text to localStorage
//     localStorage.setItem("transcribedText", data.text);
//     localStorage.setItem("savedText", data.text); // For compatibility with existing code

//     // Redirect to transcription page
//     window.location.href = "/transcribed";
//   } catch (error) {
//     console.error("Error:", error);
//     if (uploadedFileElement) {
//       uploadedFileElement.textContent = `Error: ${error.message}. Please try again.`;
//     }
//     if (uploadBtn) uploadBtn.style.display = "block";
//     if (cancelBtn) cancelBtn.style.display = "block";
//   }
// };
