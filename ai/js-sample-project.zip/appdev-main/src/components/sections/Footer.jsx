import React from "react";

const Footer = () => (
  <footer className="footer">
    <hr />
    <div className="footer-content">
      <p>© 2025 WHSPR</p>
    </div>
  </footer>
);

export default Footer;
