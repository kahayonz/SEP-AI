import React from "react";
import Soundwave from '../../assets/images/Soundwave.png';

const BottomPart = () => (
  <section className="bottom-part">
    <div className="bottom-content">
      <h3>Experience the Future of Audio Processing</h3>
      <p>
        Turn spoken words into valuable insights with ease. Start now and
        revolutionize the way you handle audio content!
      </p>
    </div>
    <img src={Soundwave} alt="Descriptive Image" style={{ maxWidth: "35%" }} />
  </section>
);

export default BottomPart;
