import React from "react";
import { useTheme } from "../../context/ThemeContext"; // Import useTheme hook
import lightIcon from "../../assets/images/light-mode.png"; // Update path if needed
import darkIcon from "../../assets/images/dark-mode.png";  // Update path if needed
import wordmark from "../../assets/images/wordmark.png";

const Header = () => {
  const { isDarkMode, toggleTheme } = useTheme(); // Access theme state and toggle function

  return (
    <header>
      <h1>
        <a href="/" className="wordmark">
          <img style={{ width: "100px", height: "auto" }} src={wordmark} alt="WHSPR" />
        </a>
      </h1>
      <nav>
  <a href="/logout" className="btn logout-btn">Logout</a>
  <button onClick={toggleTheme} className="btn theme-toggle-btn">
    <img
      src={isDarkMode ? lightIcon : darkIcon}
      alt={isDarkMode ? "Light Mode" : "Dark Mode"}
      className="theme-icon"
    />
  </button>
</nav>
    </header>
  );
};

export default Header;