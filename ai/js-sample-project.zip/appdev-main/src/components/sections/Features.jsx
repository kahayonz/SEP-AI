import React from "react";
import "../../stylesheets/global.css";
import TranscribeIcon from "../../assets/images/Transcribe-Icon.png";
import MultiLanguageIcon from "../../assets/images/MultiLanguage-Icon.png";
import SummarizeIcon from "../../assets/images/Summarize-Icon.png";

const featuresData = [
    {
      icon: TranscribeIcon,
      title: "TRANSCRIBE SPEECH TO TEXT",
      points: [
        "AI-powered transcription converts <br> spoken words into precise text.",
        "Download or copy your transcript <br> instantly.",
      ],
    },
    {
      icon: MultiLanguageIcon,
      title: "MULTI-LANGUAGE TRANSLATION",
      points: [
        "Enhances understanding in your <br> preferred language.",
        "Retains context and meaning for <br> accurate translations.",
      ],
    },
    {
      icon: SummarizeIcon,
      title: "SUMMARIZE KEY POINTS",
      points: [
        "AI extracts key insights from <br> lengthy transcripts.",
        "Save time by generating a concise <br>and clear summary.",
      ],
    },
  ];
  
  const Features = () => (
    <section className="features">
      {featuresData.map((feature, index) => (
        <div className="feature-item" key={index}>
          <img src={feature.icon} alt={`Icon ${index + 1}`} className="icon" />
          <h3>{feature.title}</h3>
          <ul>
            {feature.points.map((point, i) => (
              <li key={i} dangerouslySetInnerHTML={{ __html: point }} />
            ))}
          </ul>
        </div>
      ))}
    </section>
  );
  

export default Features;
