import React from "react";
import "../../stylesheets/global.css";

const FeatureItem = ({ icon, title, points = [] }) => (
  <div className="feature-item">
    <img src={icon} alt={title} className="icon" />
    <h3>{title}</h3>
    <ul>
      {points.map((point, index) => (
        <li key={index}>{point}</li>
      ))}
    </ul>
  </div>
);


export default FeatureItem;
