import React from "react";

const Benefits = () => (
  <section className="benefits">
    <div className="benefits-content">
      <h3>Who Benefits from Our Platform?</h3>
      <p>
        <strong>Researchers</strong> can easily transcribe interviews, focus groups,
        and recorded discussions, making it simpler to analyze data. Summaries
        help highlight key findings, while translations enable seamless
        collaboration across different languages.
      </p>
      <p>
        <strong>Students</strong> can convert lectures into structured text for
        better studying, generate concise summaries for quick review, and
        translate materials into different languages to enhance learning.
      </p>
      <p>
        <strong>Professionals</strong> can efficiently document meetings and
        brainstorming sessions, extract key points for easy reference, and
        improve accessibility with multilingual translations.
      </p>
    </div>
  </section>
);

export default Benefits;
