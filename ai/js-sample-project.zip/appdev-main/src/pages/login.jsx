import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../stylesheets/global.css";
import "../stylesheets/login.css";

const Alert = ({ message, onClose }) => (
  <div className="alert">
    <span>{message}</span>
    <button onClick={onClose}>×</button>
  </div>
);

const Login = () => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    name: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (isForgotPassword) {
        const response = await fetch("https://appdev-z193.onrender.com/api/reset_password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: formData.email }),
        });
        
        setAlertMessage("Check your email for a password reset link.");
        setShowAlert(true);
        return;
      }

      if (isLogin) {
        try {
          const response = await fetch("https://appdev-z193.onrender.com/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: formData.email, password: formData.password }),
          });
          
          const responseData = await response.json();
          
          // Check if login was successful (status 200)
          if (response.status === 200) {
            // Check for token in different possible locations in the response
            const token = responseData.token || responseData.access_token || responseData.access;
            
            if (token) {
              localStorage.setItem('token', token);
              // Force a full page reload to ensure all auth state is properly set
              window.location.href = '/';
              return;
            } else {
              setAlertMessage('Login successful but no token received in response');
              setShowAlert(true);
            }
          } else {
            // If we get here, the status wasn't 200
            const errorMessage = responseData.detail || 
                                responseData.message || 
                                responseData.error || 
                                'Login failed. Please try again.';
            setAlertMessage(errorMessage);
            setShowAlert(true);
          }
        } catch (error) {
          console.error('Login error:', error);
          setAlertMessage('An error occurred during login. Please try again.');
          setShowAlert(true);
        }
      } else {
        if (formData.password !== formData.confirmPassword) {
          setAlertMessage("Passwords do not match.");
          setShowAlert(true);
          return;
        }
        const response = await fetch("https://appdev-z193.onrender.com/api/sign-up", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ firstName: formData.name, email: formData.email, password1: formData.password, password2: formData.confirmPassword }),
        });
        const data = await response.json();
        if (response.status !== 201) {
          setAlertMessage(data.error);
          setShowAlert(true);
          return;
        }
        // For signup, redirect to login page after successful registration
        setAlertMessage('Registration successful! Please log in.');
        setShowAlert(true);
        setIsLogin(true);
      }
    } catch (error) {
      console.error("Error:", error);
      setAlertMessage(error.message || 'An error occurred');
      setShowAlert(true);
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <div className="login-header">
          <h2>
            {isForgotPassword
              ? "Reset Password"
              : isLogin
              ? "Welcome Back"
              : "Create Account"}
          </h2>
          <p>
            {isForgotPassword
              ? "Enter your email to reset your password"
              : isLogin
              ? "Sign in to continue to your account"
              : "Sign up to get started"}
          </p>
        </div>
        {showAlert && <Alert message={alertMessage} onClose={() => setShowAlert(false)} />}
        <form onSubmit={handleSubmit}>
          {!isLogin && !isForgotPassword && (
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Enter your full name"
                autoComplete="name"
              />
            </div>
          )}
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="Enter your email"
              autoComplete="email"
            />
          </div>
          {!isForgotPassword && (
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="Enter your password"
                autoComplete={isLogin ? "current-password" : "new-password"}
              />
            </div>
          )}
          {!isLogin && !isForgotPassword && (
            <div className="form-group">
              <label htmlFor="confirmPassword">Confirm Password</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                placeholder="Confirm your password"
                autoComplete="new-password"
              />
            </div>
          )}
          <button type="submit" className="login-btn">
            {isForgotPassword
              ? "Send Reset Link"
              : isLogin
              ? "Sign In"
              : "Sign Up"}
          </button>
        </form>
        <div className="switch-form">
          {isForgotPassword ? (
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                setIsForgotPassword(false);
              }}
            >
              Back to Login
            </a>
          ) : (
            <>
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  setIsLogin(!isLogin);
                }}
              >
                {isLogin ? "Sign Up" : "Sign In"}
              </a>
              {isLogin && (
                <div className="forgot-password">
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setIsForgotPassword(true);
                    }}
                  >
                    Forgot Password?
                  </a>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;
