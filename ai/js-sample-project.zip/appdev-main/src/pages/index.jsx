import React from "react";
import "../stylesheets/global.css";
import UploadArea from "../components/upload section/UploadArea";
import Header from "../components/sections/Header";
import Features from "../components/sections/Features";
import Benefits from "../components/sections/Benefits";
import BottomPart from "../components/sections/BottomPart";
import Footer from "../components/sections/Footer";

const Index = () => {
  // React.useEffect(() => {
  //   localStorage.clear(); // Clear localStorage on component load
  // }, []);

  return (
    <>
      <Header />
      <UploadArea />
      <Features />
      <Benefits />
      <BottomPart />
      <Footer />
    </>
  );
};

export default Index;
