import React from "react";
import SummarizeArea from "../components/upload section/SummarizeArea";
import Header from "../components/sections/Header";
import Features from "../components/sections/Features";
import FeatureItem from "../components/sections/FeatureItem";
import Benefits from "../components/sections/Benefits";
import BottomPart from "../components/sections/BottomPart";
import Footer from "../components/sections/Footer";

const Index = () => {
  // React.useEffect(() => {
  //   localStorage.clear(); // Clear localStorage on component load
  // }, []);

  return (
    <>
      <Header />
      <SummarizeArea />
      {/* <Features />
      <Benefits />
      <BottomPart />
      <Footer /> */}
    </>
  );
};

export default Index;
