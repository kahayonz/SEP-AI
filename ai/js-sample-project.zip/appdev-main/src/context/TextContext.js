import React, { createContext, useState, useEffect } from "react";

export const TextContext = createContext();

export function TextProvider({ children }) {
  const [text, setText] = useState(() => {
    // Load saved text from localStorage on initialization
    return localStorage.getItem("savedText") || "";
  });

  useEffect(() => {
    // Save text to localStorage whenever it changes
    localStorage.setItem("savedText", text);
  }, [text]);

  return (
    <TextContext.Provider value={{ text, setText }}>
      {children}
    </TextContext.Provider>
  );
}
