import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { TextProvider } from "./context/TextContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Index from "./pages/index";
import Summarize from "./pages/summarize"; 
import Translate from "./pages/translate"; 
import Transcribed from "./pages/transcribed";
import Login from "./pages/login";
import Logout from "./components/Logout";

function App() {
  return (
    <TextProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<Login />} />
          
          {/* Protected Routes */}
          <Route path="/" element={
            <ProtectedRoute>
              <Index />
            </ProtectedRoute>
          } />
          
          <Route path="/summarize" element={
            <ProtectedRoute>
              <Summarize />
            </ProtectedRoute>
          } />
          
          <Route path="/translate" element={
            <ProtectedRoute>
              <Translate />
            </ProtectedRoute>
          } />
          
          <Route path="/transcribed" element={
            <ProtectedRoute>
              <Transcribed />
            </ProtectedRoute>
          } />

          <Route path="/logout" element={
            <ProtectedRoute>
              <Logout />
            </ProtectedRoute>
          } />
          
        </Routes>
      </Router>
    </TextProvider>
  );
}

export default App;
